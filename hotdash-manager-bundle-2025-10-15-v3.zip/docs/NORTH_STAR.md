# NORTH_STAR — 12‑Month Outcomes

**Mission:** Operator‑first control center for Shopify with agentic workflows that reduce CEO workload.

**Quarterly Targets**
- P95 tile load < 3s
- 80% of escalations actioned in‑dashboard
- Nightly rollup error rate < 0.5%
- Pilot NPS ≥ 45

**Non‑Goals:** Theme tweaks; campaign orchestration UIs.
