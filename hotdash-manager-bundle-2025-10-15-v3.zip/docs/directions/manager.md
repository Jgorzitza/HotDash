# Direction: manager

## Objective
- …

## Constraints
- …

## DoD
- …
