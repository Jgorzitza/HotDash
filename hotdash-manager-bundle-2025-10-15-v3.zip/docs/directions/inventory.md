# Direction: inventory

## Objective
- …

## Constraints
- …

## DoD
- …
