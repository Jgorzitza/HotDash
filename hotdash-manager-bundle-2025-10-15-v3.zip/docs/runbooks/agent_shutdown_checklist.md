# Agent Shutdown (Daily)

- [ ] Update feedback log with blockers/outcomes & PR links
- [ ] Ensure tests/metrics in PR meet the DoD
- [ ] Request review; do not merge your own PR
- [ ] No Markdown created outside allow‑list; run docs policy locally if unsure
